# CubeSandbox 启动分析报告

并发 3；正式计划请求 9；正式进程内置预热 0。

## 整轮耗时

| 口径 | 耗时 | 数据来源 | 覆盖范围 |
| --- | --- | --- | --- |
| 正式测试整轮耗时 | 3089.5753 ms | raw.summary.total_time_s | Runner's measured formal workload, excluding warmup under the cube-bench contract. Includes scheduling and result collection; create-delete mode also includes deletion. Generic producers must use this same scope. |
| 外部命令窗口 | 3207.203857 ms | manifest.command.started_at/ended_at | Collector's external-command wall-clock window; may include warmup, setup, cleanup and console draining. Not the formal benchmark duration. |
| 采集窗口 | 4209.373047 ms | manifest.started_at/ended_at | Collector's entire wall-clock capture window, including surrounding log/metrics collection. Not the formal benchmark duration. |

整轮耗时是正式测试从开始到结束的经过时间，不是单次延迟的总和或最大值。外部命令可能包含预热、初始化、清理；采集窗口还可能包含 metrics 和日志收尾。整轮计时缺失时不使用后两者代替。

## 单次启动时延

| 指标 | 值 |
| --- | --- |
| 有效样本数 | 未提供 |
| 平均值 (ms) | 未提供 |
| P50 (ms) | 未提供 |
| P95 (ms) | 未提供 |
| 最大值 (ms) | 未提供 |

| 请求统计 | 值 |
| --- | --- |
| observed | 9 |
| successful | 9 |
| errors | 0 |
| valid_latency | 0 |

## warmup 与样本口径

warmup 是正式测量前的预热操作，用于让连接、缓存和资源池预先被使用。官方 cube-bench 串行执行预热，然后开始正式测试；create-only 每次创建，create-delete 每次还包含删除；预热不进入其正式 raw 样本和 summary.total_time_s。自定义 runner 必须明确自己的计时和样本范围。预热不保证消除所有冷启动开销。



组件分组状态：declared。unknown_phase 可能混有预热；declared 仅表示用户声明。阶段样本集合与客户端样本集合不一定相同，父子与并行阶段不能相加。

## 已观测阶段

| 分组 | 归属实例数 | 有观测的阶段数 | 统计口径 |
| --- | --- | --- | --- |
| formal | 9 | 9 | 正式集合；归属证据及限制见下文 |
| warmup | 0 | 0 | 预热集合 |
| unknown_phase | 0 | 0 | 实例已归属本轮，但正式/预热阶段未确认；保留观测，不用于正式分布 |

共展示 9 个分组阶段的观测统计；unknown_phase 中有观测的阶段同样展示，不会因为分组未知而隐藏。未观测阶段与全部覆盖缺口见阶段 CSV 和 analysis.json。

| 分组 | 阶段 | 实例覆盖 | 样本数 | 平均 ms | P50 ms | P95 ms | 最大 ms |
| --- | --- | --- | --- | --- | --- | --- | --- |
| formal | Shim.PauseToSnapshot | 9/9 | 9 | 13.666667 | 14 | 17 | 17 |
| formal | Shim.PauseToSnapshot.AcquireSandboxLock | 9/9 | 9 | 0 | 0 | 0 | 0 |
| formal | Shim.PauseToSnapshot.DisconnectAgent | 9/9 | 9 | 0 | 0 | 0 | 0 |
| formal | Shim.PauseToSnapshot.PrepareDirs | 9/9 | 9 | 0 | 0 | 0 | 0 |
| formal | Shim.PauseToSnapshot.ValidateConfig | 9/9 | 9 | 0 | 0 | 0 | 0 |
| formal | Shim.PauseToSnapshot.VmmSnapshot | 9/9 | 9 | 13.555556 | 14 | 16 | 16 |
| formal | Master response.cube-e2e | 9/9 | 9 | 50.555556 | 49 | 56 | 56 |
| formal | Master response.sandbox-probe | 9/9 | 9 | 12.444444 | 12 | 15 | 15 |
| formal | Master response.all-probe | 9/9 | 9 | 12.444444 | 12 | 15 | 15 |

查看 [阶段 CSV](stage-latency.csv)、[完整分析 JSON](analysis.json) 和 [runner 原始结果与校验记录](benchmark-inputs/)。

## 数据文件

- [完整汇总 JSON](run-summary.json)
- [完整分析 JSON](analysis.json)
- [阶段 CSV](stage-latency.csv)
- [实例时间轴](timeline.html)
- [客户端原始输入（未脱敏）](benchmark-inputs/)
- [输入校验清单](analysis-manifest.json)

benchmark-inputs 保留已提供的客户端结果文件原始字节；没有输入时目录为空。原始输入及报告可能包含敏感信息，分享前需检查。

## 数据限制

- Command/capture timestamps use collector wall time and can be affected by clock adjustments; they are not monotonic runner timing.
- Phase labels are caller-declared, not independently verified against benchmark execution.
- Phase map is caller-declared, NOT independently verified against benchmark execution.
- Whole-run duration measures concurrent workload completion, not a sum or maximum of individual request latencies.
- Timing fields and generic clock declarations are producer-supplied evidence; they do not independently certify workload execution or success.
- Request counts describe supplied raw rows; missing raw input remains unknown even when a summary reports totals.
- create_latency_ms is the existing profile.benchmark.create distribution of valid successful samples, not whole-run timing.
